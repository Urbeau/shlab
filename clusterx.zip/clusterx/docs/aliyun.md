# 阿里云配置 clusterx

### 配置 clusterx


## 方法一：交互式填写配置文件

1. 执行 clusterx 命令，触发自动配置，选择阿里云作为集群名:

    ```console
    clusterx --help

    输入集群名 (['aliyun', 'volc']) >>> [火山云填写 volc，阿里云填写 aliyun]
    ```

2. 选择默认分区，该分区会作为后续命令行启动任务的默认分区：

   ```console
   配置默认阿里云分区 ['alillm_hs', 'alillm_hc', 'alillm_h4', 'alillm_h3', 'alillm_h2', 'alillm_h1', 'llm_ddd', 'llm_dev', 'llm_razor', 'unbinded', 'all'] >>>
   ```

3. 选择镜像地址

   ```console
   配置默认阿里云镜像，查询地址：
   http://pai-console.cda8b74cb9cf64340ab0a0b889e4beec5.cn-shanghai.alicontainer.com/index?workspaceId=ws142uih39u48m91#/dlc2/images
   ```

   阿里云任务启动需要选择一个镜像作为任务的运行环境，可以在阿里云的镜像仓库中查看，如果不知道选什么镜像，可以直接填入：

   pjlab-shanghai-acr-registry-vpc.cn-shanghai.cr.aliyuncs.com/paieflops/yehaochen:yehaochen-1111

   作为默认镜像

4. 选择数据挂载路径

   ```console
   以逗号为分隔符，输入 datasources id，查询地址：
   http://pai-console.cda8b74cb9cf64340ab0a0b889e4beec5.cn-shanghai.alicontainer.com/index?workspaceId=ws142uih39u48m91#/dlc2/datasources/hostPath
   >>>
   ```

   任务执行时需要将需要访问的文件挂载到容器中，目前阿里云集群默认只会把个人目录：`/cpfs01/user/${USER}` 和共享目录 `/cpfs01/shared/public` 挂载到容器里，如果需要访问其他目录，则需要指定 datasource id 进行手动挂载。

   例如如果想在容器内访问 `/cpfs01/shared/llm_ddd` 和 `/cpfs01/shared/alillm_h1/` 下的数据，就需要以**逗号**为分隔符，传入 datasources id：`data1otmepzybpqr,data26j4snc3a2u1`

5. 配置容器内可访问的公共目录

   ```console
   配置任务节点可访问公共目录，回车默认使用 /cpfs01/user/yehaochen/.tmp  >>>
   ```

   clusterx 要求填入一个任务执行时可以访问到的公共目录，这个目录通常是和上一步填入的挂载目录相关。不过考虑到阿里云默认会挂载 `/cpfs01/user/${USER}`，所以这里可以直接填入 `/cpfs01/user/${USER}/.tmp` 作为默认值

6. 配置阿里云用户配置

   用户信息可以在阿里云的控制台右上角查看，如果不知道可以询问阿里云集群分区管理员

   ```console
   Cannot found dlc config, create a new one:
   access_id:yehaochen
   access_key:{access_key}
   ```

## 方法二：直接编辑配置文件

> 具体字段可以参考[交互式填写配置文件](#方法一：交互式填写配置文件)

创建 `~/.clusterx/config.yaml` 文件，填入如下内容：

```yaml
aliyun:
  data_sources:
  - data1otmepzybpqr # <数据挂载目录>
  - data26j4snc3a2u1
  image: pjlab-shanghai-acr-registry-vpc.cn-shanghai.cr.aliyuncs.com/paieflops/yehaochen:yehaochen-1111  # 镜像地址
  partition: alillm_h1  # 分区名
  tmpdir: /cpfs01/user/yehaochen/.tmp  # 任务内可访问的公共目录
default: aliyun
volc: null
```

创建 `~/.dlc/config`，填入用户信息

```ini
[user]
access_id = "yehaochen"
access_key = ""
```
