from clusterx.utils import StrEnum
from clusterx.config import CLUSTERX_CONFIG, BrainppConfig
from clusterx.constant import brainpp_partition_group

from pydantic import TypeAdapter

brainpp_adapter = TypeAdapter(BrainppConfig)

cluster_name = CLUSTERX_CONFIG.default
cluster_cfg = getattr(CLUSTERX_CONFIG, cluster_name)
if brainpp_adapter.validate_python(cluster_cfg):
    if (yidian_cfg := CLUSTERX_CONFIG.yidian) is not None:
        custom_partition: list[str] = cluster_cfg.get("custom_partition") or []

        builtin_partition = tuple(i[0] for i in brainpp_partition_group)
        for partition in custom_partition:
            if partition in builtin_partition:
                continue
            brainpp_partition_group.append(partition)


BrainppPartition = StrEnum(
    "BrainppPartition",
    zip(brainpp_partition_group, brainpp_partition_group),
)
