import asyncio
import json
import os
import re
import time
import typing as T
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated, List, cast

import aiohttp
import requests
from brainpp.rjob import (
    Affinity,
    Job,
    JobStatusType,
    Metadata,
    PrivateMachine,
    Resources,
    RestartPolicy,
    RJobClient,
    Spec,
    Task,
    Template,
)
from cyclopts import Parameter
from rich import print
from rich.console import Console
from rich.prompt import Confirm
from rich.table import Column, Table
from tenacity import (
    retry,
    retry_if_exception_type, 
    stop_after_attempt,
    wait_fixed,
    RetryError,
)

from clusterx.logger import getLogger

from ..base import (
    BaseCluster,
    BaseRunParams,
    JobSchema,
    JobStatus,
    NodeSchema,
    NodeStatus,
)
from .brainpp_info import BrainppPartition

STATUS_MAPPING = {
    "Created": JobStatus.RUNNING,
    "Restarting": JobStatus.RUNNING,
    "Starting": JobStatus.RUNNING,
    "Running": JobStatus.RUNNING,
    "Killing": JobStatus.RUNNING,
    "Killed": JobStatus.STOPPED,
    "Deleting": JobStatus.STOPPED,
    "Succeeded": JobStatus.SUCCEEDED,
    "Failed": JobStatus.FAILED,
    "Pending": JobStatus.QUEUING,
    "Stopped": JobStatus.STOPPED,
}


@Parameter(name="*")
class BrainppRunparams(BaseRunParams[BrainppPartition]):
    delete_exist: Annotated[bool, Parameter(help="是否删除重名的任务")] = False
    mount: Annotated[
        str | None,
        Parameter(help="挂载路径，例如 gpfs+gpfs://gpfs1/chenhaodong:/mnt/chenhaodong,如果有多个挂载路径，请以逗号为分隔符输入"),
    ] = None  # noqa: E501
    image: Annotated[str | None, Parameter(help="镜像 url，默认使用 `~/.config/cluster.yaml` 设置的镜像")] = None
    tmpdir: Annotated[str | None, Parameter(help="任务节点可访问公共目录，默认使用 clusterx.yaml 中的路径")] = None


logger = getLogger("clusterx.launcher.brainpp")


class BrainppCluster(BaseCluster):
    """Brainpp 任务发布器，负责创建并提交任务，在提交前检查是否有同名任务."""

    def __init__(self):
        """初始化 RJobClient 客户端."""
        from clusterx.config import CLUSTERX_CONFIG, BrainppConfig

        cluster_cfg = getattr(CLUSTERX_CONFIG, CLUSTERX_CONFIG.default)
        assert cluster_cfg is not None
        self.clusterx_cfg = cast(BrainppConfig, cluster_cfg)
        self.client = RJobClient(
            cluster_entry="https://h.pjlab.org.cn",
            namespace=self.clusterx_cfg["project_name"],
            access_key=self.clusterx_cfg["access_key"],
            secret_key=self.clusterx_cfg["secret_key"],
        )

    def run(self, run_params: BrainppRunparams) -> JobSchema:
        # 检查是否有同名任务
        job_name = run_params.job_name

        if self._check_job_exists(job_name):
            logger.info(f"存在同名任务: {job_name}，删除同名任务")
            if run_params.delete_exist:
                self.client.delete([job_name])
                # 等待删除操作完成
                time.sleep(2)
            else:
                raise RuntimeError(f"任务 {job_name} 请手动删除或者取其他名字")

        cmd = self._build_command(run_params.cmd, run_params.no_env)

        if run_params.tmpdir is not None:
            tmpdir = Path(run_params.tmpdir)
        else:
            assert self.clusterx_cfg["tmpdir"], "未在配置文件中发现 tmpdir, 请手工设置"
            tmpdir = Path(self.clusterx_cfg["tmpdir"])

        cmd_name = uuid.uuid4()
        cmd_path = tmpdir / f"{cmd_name}.sh"
        cmd_path.parent.mkdir(parents=True, exist_ok=True)

        with open(cmd_path, "w") as f:
            f.write(cmd)

        if self.clusterx_cfg["is_in_workspace"]:
            cmd = f"bash {cmd_name}.sh"
            no_packaging = True
            packaging_dir = None
        else:
            cmd = f"cd /workdir/rjob/src && bash {cmd_name}.sh"
            no_packaging = False
            packaging_dir = str(tmpdir)
        image = self._get_image(run_params)
        partition = self._get_partition(run_params)
        mount = self._get_mount(run_params)
        job = self._create_job_spec(
            cmd=cmd,
            job_name=job_name,
            image=image,
            num_cpu=run_params.cpus_per_task,
            num_gpu=run_params.gpus_per_task,
            memory_mb=run_params.memory_per_task * 1000,
            preemptible=run_params.preemptible,
            group=partition,
            include_nodes=run_params.include,
            exclude_nodes=run_params.exclude,
            replicas=run_params.num_nodes,
            retry=run_params.retry,
            mount=mount,
        )

        # 提交任务
        rjob_name = self.client.submit(job, no_packaging=no_packaging, packaging_dir=packaging_dir)
        job_schema = self.get_job_info(rjob_name)
        logger.info(f"任务 {job_schema.job_name} 创建成功")
        # logger.info(job_schema.model_dump_json(indent=4))
        return job_schema

    def stop(
        self,
        *,
        job_id: str | None = None,
        regex: str | None = None,
        group: str | None = None,
        user: str | None = None,
        partition: BrainppPartition | None = None,
        status: JobStatus | None = None,
        confirm: bool = False,
    ) -> None:
        if group is not None:
            raise NotImplementedError("暂不支持按照分组删除任务")

        if job_id is not None:
            self.client.stop(job_id)
            logger.info(f"任务 {job_id} 已停止")
        else:
            jobs = self.client.list()
            if not jobs:
                logger.info("没有需要被停止的任务")
                return
            filtered_jobs: list[str] = []
            for job in jobs:
                job_user = self._get_job_user(job)
                job_partiton = self._get_job_partition(job)
                job_name = self._get_job_name(job)
                if job_user != user:
                    continue
                if partition is not None and job_partiton != partition.name:
                    continue
                if regex is not None and not re.search(regex, job_name):
                    continue
                job_status = self._get_job_status(job)
                if status is not None and job_status != status:
                    continue
                filtered_jobs.append(job_name)

            if not filtered_jobs:
                logger.info("未找到匹配的任务")
                return

            if confirm:
                console = Console()
                confirm_check = Confirm("是否删除以上任务？", console=console)

                table = Table(
                    Column("任务名", min_width=40, max_width=80, overflow="ellipsis"),
                    Column("任务 ID", max_width=20),
                    Column("任务状态", max_width=20),
                    Column("用户名", max_width=20),
                    Column("所属分区", max_width=20),
                )
                for job in filtered_jobs:
                    table.add_row(
                        job["DisplayName"],
                        job["JobId"],
                        job["Status"],
                        job["UserId"],
                        job["WorkspaceName"],
                    )
                console.print(table, highlight=True)

                if not confirm_check.ask():
                    return

            for job in filtered_jobs:
                self.client.stop(job)

    def stats_node_cli(
        self,
        partition: Annotated[BrainppPartition, Parameter(help="分区名")],
        /,
        *,
        out: Annotated[Path | None, Parameter(name=["--out", "-o"])] = None,
        verbose: Annotated[bool, Parameter(name=["--verbose", "-v"])] = True,
    ):
        """统计分区的节点信息，在底层设置 verbose 和  out 接口是为了方便记录集群相关的完整信息."""
        self.stats_node(partition.value, out=out, verbose=verbose)

    def stats_node(self, /, partition: str, *, out: Path | None = None, verbose=False) -> list[NodeSchema]:
        """统计分区的节点信息."""
        nodes_schema = self._get_stats_node(partition)
        if out is not None:
            out.parent.mkdir(exist_ok=True, parents=True)
            with out.open("w") as f:
                json.dump([n.model_dump() for n in nodes_schema], f, indent=4)

        if verbose:
            # 创建表格显示节点信息
            table = Table(
                Column("节点名", max_width=50),
                Column("状态", max_width=20),
                Column("总 GPU", max_width=20),
                Column("总 CPU", max_width=20),
                Column("总内存(GB)", max_width=20),
            )

            for node in nodes_schema:
                table.add_row(
                    node.name,
                    str(node.status),
                    str(node.total_gpu),
                    str(node.total_cpu),
                    str(node.total_memory),
                )

            print(table)

            # 打印汇总信息
            summarize = Table("总节点数", "正常节点数", "坏节点数", "空闲节点数")
            summarize.add_row(
                str(len(nodes_schema)),
                str(len([n for n in nodes_schema if n.status != NodeStatus.DRAIN])),
                str(len([n for n in nodes_schema if n.status == NodeStatus.DRAIN])),
                str(len([n for n in nodes_schema if n.status == NodeStatus.IDLE])),
            )
            print(summarize)

        return nodes_schema

    def get_node_info(self, /, node: str, *, out: Path | None = None, verbose=False) -> NodeSchema:
        """获取节点详细信息, 在底层设置 verbose 和 out 接口是为了方便集群相关的完整信息."""
        raise NotImplementedError()

    def list_jobs(
        self,
        *,
        group: str | None = None,
        user: str | None = None,
        partition: BrainppPartition | None = None,
        status: JobStatus | None = None,
        regex: str | None = None,
        num: int = 20,
        out: Path | None = None,
        verbose: bool = False,
    ) -> list[JobSchema]:
        raise NotImplementedError()

    def get_job_info(self, /, job_id: str, verbose=False) -> JobSchema:
        jobs = self.client.list(job_names=[job_id])
        if jobs is None or len(jobs) == 0:
            raise RuntimeError(f"Cannot find {job_id}")
        job = jobs[0]
        job_dict = job.to_dict()
        tasks = job_dict["spec"]["tasks"]
        assert len(tasks) == 1, "暂时不支持多任务 job 的获取"
        task = next(iter(tasks.values()))
        resources = task["template"]["containers"][0]["resources"]
        replica_node_map = self._get_replica_node_map(job)
        nodes = [f"{replica_id}:{node_name}" for replica_id, node_name in replica_node_map.items()]
        # metadata = self._get_replica_metadata(job_id)
        # print(metadata)
        job_schema = JobSchema(
            job_id=job_id,  # 或许可以替换成 k8s create id？
            user=self._get_job_user(job),
            gpus_per_node=resources["gpu"],
            cpus_per_node=resources["cpu"],
            memory=f"{resources['memoryInMB'] // 1024:.3f}G",
            status=self._get_job_status(job),
            num_nodes=task["replicas"],
            partition=self._get_job_partition(job),
            job_name=job_id,
            cmd=" ".join(task["template"]["command"]),
            nodes=nodes,
        )
        if verbose:
            print(job_schema)
        return job_schema

    def get_log(self, job_id: str) -> str:
        logs = self.client.logs_rjob(job_id)
        return logs

    async def async_get_job_info(self, /, job_id: str, verbose=False) -> JobSchema:
        raise NotImplementedError()

    def run_cli(
        self, *cmd: Annotated[str, Parameter(allow_leading_hyphen=True)], run_params: BrainppRunparams | None = None
    ) -> JobSchema:
        if run_params is None:
            run_params = BrainppRunparams()
        run_params.cmd = " ".join(cmd)
        return self.run(run_params)

    def list_cli(
        self,
        *,
        group: str | None = None,
        user: Annotated[str | None, Parameter(name=["--user", "-u"])] = None,
        partition: Annotated[BrainppPartition | None, Parameter(name=["-p", "--partition"])] = None,
        status: Annotated[JobStatus | None, Parameter(name=["--status", "-s"])] = None,
        regex: Annotated[str | None, Parameter(help="匹配任务名的正则表达式")] = None,
        num: Annotated[int, Parameter(help="匹配任务名的正则表达式")] = 20,
        out: Annotated[Path | None, Parameter(name=["--out", "-o"])] = None,
        verbose: Annotated[bool, Parameter(name=["--verbose", "-v"])] = True,
    ):
        raise NotImplementedError()

    def stop_cli(
        self,
        *,
        job_id: Annotated[str | None, Parameter(name=["--job-id", "-j"])] = None,
        regex: Annotated[str | None, Parameter(help="匹配任务名的正则表达式")] = None,
        group: Annotated[str | None, Parameter(name=["--group", "-g"])] = None,
        user: Annotated[str | None, Parameter(name=["--user", "-u"])] = None,
        partition: Annotated[BrainppRunparams | None, Parameter(name=["-p", "--partition"])] = None,
        status: Annotated[JobStatus | None, Parameter(name=["-status", "-s"])] = None,
        confirm: Annotated[bool, Parameter(name=["--confirm", "-c"])] = False,
    ) -> None:
        self.stop(job_id=job_id, regex=regex, group=group, user=user, partition=partition, confirm=confirm)

    def _create_job_spec(
        self,
        cmd: str,
        job_name: str,
        image: str,
        num_cpu: int,
        num_gpu: int,
        memory_mb: int,
        preemptible: bool | None,
        group: str,
        include_nodes: str | None,
        exclude_nodes: str | None,
        replicas: int,
        retry: bool,
        mount: list[str] | None,
    ):
        """创建任务规范.

        参数:
            cmd: 执行命令
            job_name: 任务名称
            image: 容器镜像
            num_cpu: CPU 数量
            num_gpu: GPU 数量
            memory_mb: 内存大小（MB）
            preemptible: 是否可抢占
            group: 分组名称
            include_nodes: 指定节点列表
            exclude_nodes: 排除节点列表
            replicas: 副本数量
            retry: 是否重试
            mount: 挂载路径列表

        返回:
            Job 对象
        """
        # 创建亲和性配置
        include_nodes_list = self._normalize_node_list(include_nodes)
        exclude_nodes_list = self._normalize_node_list(exclude_nodes)
        affinity = Affinity(positive_tags=include_nodes_list, negative_tags=exclude_nodes_list)

        if replicas > 1:
            custom_resources = ["rdma/mlnx_shared=8", "mellanox.com/mlnx_rdma=1"]
            environment = {
                "DISTRIBUTED_JOB": "true",
            }
            gang_start = True
        else:
            custom_resources = None
            environment = None
            gang_start = False

        if retry:
            restart_policy = RestartPolicy.RestartJobOnFailure
        else:
            restart_policy = RestartPolicy.Never

        # 创建任务模板
        template = Template(
            image=image,
            command=["bash", "-ecx", f"{cmd}"],
            resources=Resources(
                cpu=num_cpu,
                gpu=num_gpu,
                memory_in_mb=memory_mb,
                custom_resources=custom_resources,
            ),
            environments=environment,
            mount=mount,
        )

        # 创建任务规范
        rjob_spec = Spec(
            affinity=affinity,
            preemptible=preemptible,
            group=group,
            gang_start=gang_start,
            host_network=True,
            tasks={
                "task": Task(
                    replicas=replicas,
                    restart_policy=restart_policy,
                    private_machine=PrivateMachine.Group,
                    template=template,
                    # max_running_duration=task_config["max_running_duration"],
                ),
            },
        )

        # 创建Job对象
        job = Job(
            metadata=Metadata(
                name=job_name,
                charged_group=group,
            ),
            spec=rjob_spec,
        )

        return job

    def _get_stats_node(self, partition: str) -> list[NodeSchema]:
        """统计分区的节点信息."""
        # 构建 API URL
        url = f"{self.client.cluster_entry}/kapis/node.brainpp.cn/v1alpha1/nodes/details"
        params = {
            "tenant": self.client.namespace.split("-")[0],  # 从 namespace 中提取 tenant
            "project": self.client.namespace,  # project 就是 namespace
            "group": partition,  # 使用分区名作为 group
            "pageSize": 1000000, # 单页1000000节点，避免分页多次请求
        }

        # 创建认证
        auth = (self.client.username, self.client.password)
        
        # 使用 requests 发送同步请求
        response = requests.get(
            url, 
            params=params, 
            verify=self.client.verifyssl,
            auth=auth,
            timeout=30
        )
        
        if response.status_code != 200:
            raise RuntimeError(f"获取节点信息失败: HTTP {response.status_code}")
        
        data = response.json()

        if data["status"] != "Success":
            raise RuntimeError(f"获取节点信息失败: {data['status']}")

        nodes_info = data["data"]["machines"]
        nodes_schema: list[NodeSchema] = []

        for node_info in nodes_info:
            # 获取节点状态
            node_status = NodeStatus.UNRECORGNIZED
            for condition in node_info["status"]["conditions"]:
                if condition["type"] == "Ready":
                    if node_info["metadata"]["labels"]["node.brainpp.cn/maintenance"] == "true":
                        node_status = NodeStatus.DRAIN
                    elif condition["status"] == "True":
                        used = node_info["used"]
                        if int(used["cpu"]) > 0 or int(used["memory"]) > 0 or int(used["nvidia.com/gpu"]) > 0:
                            node_status = NodeStatus.MIXED
                        else:
                            node_status = NodeStatus.IDLE
                    break

            # 提取节点信息
            name = node_info["metadata"]["name"]
            capacity = node_info["status"]["capacity"]

            # 获取 GPU 数量
            total_gpu = int(capacity.get("nvidia.com/gpu", "0"))

            # 获取 CPU 数量
            total_cpu = int(capacity.get("cpu", "0"))

            # 获取内存大小（转换为 GB）
            memory_ki = capacity.get("memory", "0Ki").rstrip("Ki")
            total_memory = f"{int(memory_ki) // (1024 * 1024)}"  # 转换为 GB
            node_schema = NodeSchema(
                name=name,
                status=node_status,
                total_gpu=total_gpu,
                total_cpu=total_cpu,
                total_memory=total_memory,
            )
            nodes_schema.append(node_schema)
        return nodes_schema

    def _get_replica_node_map(self, job: Job) -> dict[str, str]:
        """获取任务中所有副本的节点映射.

        参数:
            job_name: 任务名称

        返回:
            副本ID到节点名称的映射字典
        """
        replica_node_map = {}

        if job.spec and job.spec.tasks:
            for task in job.spec.tasks.values():
                if task.replicaStatus:
                    for rs in task.replicaStatus:
                        if rs.process_id is not None and rs.process_id != "":
                            replica_node_map[rs.process_id] = rs.node_name
        return replica_node_map

    def _get_replica_metadata(self, rjob_name: str) -> dict:
        replica = self.client.api.get_namespaced_custom_object(
            group=self.client.group,
            version=self.client.version,
            namespace=self.client.namespace,
            plural="rjob",
            name=rjob_name,
        )
        return replica["metadata"]

    def _get_job_user(self, job: Job) -> str:
        labels = job.metadata.labels
        if labels is None:
            return "Unknown"
        else:
            return labels["kubebrain.brainpp.cn/creator"]

    def _get_job_partition(self, job: Job) -> str:
        spec = job.spec
        if spec is None:
            return "Unknown"
        partition = spec.group
        return partition or "Unknown"

    def _get_job_name(self, job: Job) -> str:
        metadata = job.metadata
        if metadata is None:
            return "Unknown"
        name = metadata.name
        return name or "Unknown"

    def _get_job_status(self, job: Job) -> JobStatus:
        orig_status = job.status.current.name
        return STATUS_MAPPING[orig_status]

    def _check_job_exists(self, job_name, is_running=False):
        """检查是否存在同名任务."""
        job_list = self.client.list([job_name])
        if job_list is None or len(job_list) == 0:
            return False

        if is_running:
            return (
                job_list[0].status.current in (
                    JobStatusType.Running,
                    JobStatusType.Succeeded
                )
            )
        else:
            return True

    def _build_pytorch_ddp_cmd(self):
        cmd = (
            "export MASTER_ADDR=$MASTER_ADDR\n"
            "export MASTER_PORT=6000\n"
            "export WORLD_SIZE=$NODE_COUNT\n"
            "export RANK=$NODE_RANK\n"
        )
        return cmd

    def _build_command(self, cmd: str, no_env: bool) -> str:
        _cmd = self._build_pytorch_ddp_cmd()
        exclude = {"LC_ALL"}
        if not no_env:
            env_cmd = ""
            inherited_env = {k: v for k, v in os.environ.items() if v != ""}
            for k, v in inherited_env.items():
                if k in exclude:
                    continue
                env_cmd += f"export {k}='{v}'\n"
            _cmd += env_cmd
            _cmd += f"cd {os.getcwd()}\n"
        cmd = _cmd + cmd
        return cmd

    def _get_image(self, run_params: BrainppRunparams) -> str:
        image = run_params.image or self.clusterx_cfg["image"]
        if not image:
            raise RuntimeError("请设置镜像地址")
        return image

    def _get_partition(self, run_params: BrainppRunparams) -> str:
        partition = run_params.partition or self.clusterx_cfg["partition"]

        if not partition:
            raise RuntimeError("请设置分区名")
        return partition

    def _get_mount(self, run_params: BrainppRunparams) -> list[str] | None:
        default_mount = self.clusterx_cfg["mount"]
        if run_params.mount is not None:
            default_mount += run_params.mount.split(",")
        return default_mount

    def _normalize_node_list(self, nodes: str | None) -> list[str]:
        """将节点字符串转换为标准化的节点列表.

        参数:
            nodes: 逗号分隔的节点字符串，例如 "node1,node2,node3"

        返回:
            标准化后的节点列表，每个节点名称都带有 "node/" 前缀
        """
        if not nodes:
            return []
        
        return [
            f"node/{node}" if not node.startswith("node/") else node 
            for node in nodes.split(",") 
            if node
        ]

    async def async_get_log(
        self,
        name: str,
        replicas: T.Optional[List[str]] = None,
    ) -> str:
        """获取任务副本的日志（异步版本）.

        参数:
            name: 任务名称
            replicas: 副本列表

        返回:
            日志内容
        """
        if self.client.type == "kubebrain":
            return await self._async_kubebrain_logs_rjob(
                name=name,
                replicas=replicas,
            )
        else:
            raise RuntimeError("async_logs_rjob method only for kubebrain platform!")

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_fixed(1),
        retry=retry_if_exception_type((aiohttp.ClientError, RuntimeError)),
    )
    async def _async_kubebrain_logs_rjob(
        self,
        name: str,
        replicas: T.Optional[List[str]] = None,
    ) -> str:
        """获取 kubebrain 平台任务的日志.

        参数:
            name: 任务名称
            replicas: 副本列表

        返回:
            日志内容
        """
        tenants = self.client.namespace.split("-")[0]
        rjob_endpoint = "{}/kapis/{}/v1alpha1/tenants/{}/projects/{}".format(
            self.client.cluster_entry, self.client.group, tenants, self.client.namespace
        )

        async with await self._create_brainpp_api_session() as session:
            # 检查 rjob 是否存在并获取 replicas
            uri = "{}/rjobs/{}/infos".format(
                rjob_endpoint,
                name,
            )
            async with session.get(url=uri, ssl=self.client.verifyssl) as response:
                if response.status >= 400:
                    raise RuntimeError(f"获取rjob信息失败: HTTP {response.status}")
                rjob_data = await response.json()
                if rjob_data["data"] is None or rjob_data["data"] == {}:
                    raise RuntimeError(f"获取rjob信息失败，replicas为空")
                
            replicas_list = []
            for task in rjob_data["data"]:
                replicas_list.extend(rjob_data["data"][task])

            if replicas is not None and len(replicas) > 0:
                replicas_list = replicas

            creation_time = datetime.now(timezone.utc)
            for replica_name in replicas_list:
                replica = self.client.api.get_namespaced_custom_object(
                    group=self.client.group,
                    version=self.client.version,
                    namespace=self.client.namespace,
                    plural="replicas",
                    name=replica_name,
                )
                replica_creation_time = datetime.strptime(
                    replica["metadata"]["creationTimestamp"], "%Y-%m-%dT%H:%M:%SZ"
                ).replace(tzinfo=timezone.utc)
                if replica_creation_time < creation_time:
                    creation_time = replica_creation_time

            uri = "{}/kapis/{}/{}/tenants/{}/projects/{}/rjobs/{}/logs/query_range".format(
                self.client.cluster_entry,
                self.client.group,
                self.client.version,
                self.client.namespace.split("-")[0],
                self.client.namespace,
                name,
            )
            params = {}
            params["replicas"] = replicas_list
            # maximum is 100000. if more than 100000, it will get an error.
            params["limit"] = 100000
            params["direction"] = "backward"
            start_ns = int(creation_time.timestamp() * 1e9)
            params["start"] = str(start_ns)
            # Set end to current time in nanoseconds
            end_ns = int(time.time_ns())
            params["end"] = str(end_ns)
            async with session.get(url=uri, ssl=self.client.verifyssl, params=params) as response:
                if response.status >= 400:
                    raise RuntimeError(f"获取日志失败: HTTP {response.status}")
                data = await response.json()
                return data["data"]

    async def _log_threading(self, job_id):
        """异步获取日志的生成器.

        参数:
            job_id: 任务 ID

        生成:
            每次产生新的日志行
        """
        prev_logs = ""

        while True:
            try:
                cur_logs = await self.async_get_log(job_id)
                increment_logs = cur_logs[len(prev_logs) :]
            except RetryError as e:
                # RetryError 包装了原始异常
                original_exception = e.last_attempt.exception()
                yield(f"获取日志失败，请检查{job_id}是否存在 -> {original_exception}")
                break

            if not increment_logs:
                continue

            prev_logs = cur_logs
            for line in increment_logs:
                yield line["line"]

    async def _create_brainpp_api_session(self) -> aiohttp.ClientSession:
        """创建一个带有认证的 aiohttp session.

        返回:
            配置好的 session 对象
        """
        # 创建连接器配置
        connector = aiohttp.TCPConnector(
            limit_per_host=10,  # 每个主机的连接限制
        )
        # 设置超时配置
        timeout = aiohttp.ClientTimeout(total=30)  # 30秒超时
        # 创建认证
        auth = aiohttp.BasicAuth(self.client.username, self.client.password)
        # 创建并返回 session
        return aiohttp.ClientSession(connector=connector, timeout=timeout, auth=auth)
