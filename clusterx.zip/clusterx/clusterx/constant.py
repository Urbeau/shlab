aliyun_partition_quota = [
    ("alillm_hs", "quota110xkp3pcjr"),
    ("alillm_hc", "quotahvo6pzwgju8"),
    ("alillm_he", "quota1dk84jrqkp4"),
    ("alillm_h5", "quotatllwqw1wxfc"),
    ("alillm_h3", "quotajtmqyvm2ge2"),
    ("alillm_h4", "quota1fz1b0ns9lk"),
    ("alillm_h2", "quotaevtp1jgmosy"),
    ("alillm_h1", "quota12ytbt3esxy"),
    ("llm_ddd", "quota1nvo6ivfa4p"),
    ("llm_ddd_new", "quotafdoefc10q87"),
    ("llm_dev", "quotai9pibrorx0v"),
    ("llm_razor", "quota12svgnbu3hy"),
    ("llmit1", "quota1c2pkw803uh"),
    ("unbinded", "unbinded"),
    ("all", "all"),
]


aliyun_partition_ids = [
    ("alillm_hs", "ws1lu4iyv5yjjyvp"),
    ("alillm_hc", "ws1h2vgufjufr4jj"),
    ("alillm_he", "wso1cah3ytpgmaah"),
    ("alillm_h5", "ws10jbrbciysudxx"),
    ("alillm_h4", "ws1mwr5l3yx5vz6q"),
    ("alillm_h3", "ws1f6e9s7dh69ttt"),
    ("alillm_h2", "wso1gao759kjyz4p"),
    ("alillm_h1", "ws142uih39u48m91"),
    ("llm_ddd", "ws1ujefpjyfgqjwp"),
    ("llm_ddd_new", "wssp4wsoiyvfp6ww"),
    ("llm_dev", "ws1ujs9hjg4li05e"),
    ("llm_razor", "ws1ypm687hjzj222"),
    ("llmit1", "ws7aeo7cd0ymnqrn"),
    ("unbinded", "unbinded"),
    ("all", "all"),
]

volc_partition_ids = [
    ("llmit", "q-20241107090149-fqbbn"),
    ("cpu资源", "q-20241108174555-bqk6z"),
    ("llmeval", "q-20241107090049-znfds"),
    ("llmeval_volc", "q-20241107085952-dnfrk"),
    ("eval_service", "q-20250325140725-bx2vj"),
    ("llm_d", "q-20241107090219-cjqmd"),
]

brainpp_partition_group = [
    "puyu_gpu",
    "puyu_wsp_cpu",
]
