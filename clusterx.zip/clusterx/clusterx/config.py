import os
from pathlib import Path

import yaml
from cyclopts import Parameter
from prompt_toolkit import prompt
from prompt_toolkit.completion import WordCompleter
from pydantic import BaseModel, ValidationError, model_validator
from typing_extensions import Annotated, NotRequired, TypedDict

from clusterx.constant import aliyun_partition_ids

VALID_CUSTER = ("aliyun", "volc", "yidian")

# TODO: Need to implement ClusterX PydanticModel Config to implement the validation


class AliyunConfig(TypedDict):
    image: str
    data_sources: list[str]
    partition: str
    config: NotRequired[str]
    tmpdir: str
    custom_partition: NotRequired[list[tuple[str, str]]]
    custom_quota: NotRequired[list[tuple[str, str]]]


class VolcConfig(TypedDict):
    config: NotRequired[str]
    tmpdir: str
    custom_partition: NotRequired[list[tuple[str, str]]]
    ...


class BrainppConfig(TypedDict):
    image: str
    mount: list[str]
    partition: str
    custom_partition: NotRequired[list[str]]
    tmpdir: str
    project_name: str
    access_key: str
    secret_key: str
    is_in_workspace: bool


class ClusterXConfig(BaseModel):
    default: str
    aliyun: AliyunConfig | None = None
    volc: VolcConfig | None = None
    yidian: BrainppConfig | None = None

    @model_validator(mode="before")
    def validate_input(cls, data):
        assert data["default"] in VALID_CUSTER, f"Invalid cluster name: {data['default']}"
        if (aliyun_cfg := (data.get("aliyun") or {})) and "custom_quota" in aliyun_cfg:
            aliyun_quota = aliyun_cfg["quota"]
            aliyun_partition = aliyun_cfg["partition"]
            assert len(aliyun_quota) == len(aliyun_partition), "分区和配额数量不匹配"

        return data


DEFAULT_CFG_PATH = Path().home() / ".config/clusterx.yaml"
CLUSTER: str
CLUSTERX_CONFIG: ClusterXConfig


def _set_aliyun_config():
    # prompt inside cyclopts need to add `\n` manually sometimes. ohtherwise it will be a mess
    partition_mappings = dict(aliyun_partition_ids)
    partition_names = list(partition_mappings.keys())

    partition = prompt(f"配置默认阿里云分区 {partition_names} >>> ", completer=WordCompleter(partition_names))
    workspace_id = "无默认值"

    custom_partition = None
    if partition:
        if partition not in partition_names:
            print(f"\033[32m自定义的分区名，请输入分区的 workspace id. 如果需要配置多个自定义分区，请手动编辑 {DEFAULT_CFG_PATH}\033[0m")
            workspace_id = prompt(">>>")
            custom_partition = [(partition, workspace_id)]

    # image = prompt.ask(
    #     "配置默认阿里云镜像",
    #     default="pjlab-shanghai-acr-registry-vpc.cn-shanghai.cr.aliyuncs.com/paieflops/yehaochen:yehaochen-1111",
    # )

    PAI_MIRROR = "http://pai-console.cda8b74cb9cf64340ab0a0b889e4beec5.cn-shanghai.alicontainer.com/index?workspaceId={}#/dlc2/images"  # noqa: E501
    link = "\033]8;;{link}\033\\{link}\033]8;;\033\\".format(link=PAI_MIRROR.format(workspace_id))
    print(f"配置默认阿里云镜像，查询地址：\n{link}")
    image = prompt(">>>")

    PAI_DATA = "http://pai-console.cda8b74cb9cf64340ab0a0b889e4beec5.cn-shanghai.alicontainer.com/index?workspaceId={}#/dlc2/datasources/hostPath"  # noqa: E501
    link = "\033]8;;{link}\033\\{link}\033]8;;\033\\".format(link=PAI_DATA.format(workspace_id))
    print(f"以逗号为分隔符，输入 datasources id，查询地址：\n{link}")
    data_sources_str = prompt(">>> ")
    data_sources = [item.strip() for item in data_sources_str.split(",") if item.strip()]

    config = os.environ.get("CLUSTERX_ALIYUN_CONFIG", str(Path().home() / ".dlc/config"))
    print(f"请输入阿里云配置文件，默认使用 {config}")
    config_path = prompt(">>> ")

    default_tmpdir = os.environ.get("CLUSTERX_ALIYUN_TMPDIR", str(Path().home() / ".tmp"))
    print(f"请输入任务节点可访问公共目录，回车默认使用 {default_tmpdir}\n")
    tmpdir = prompt(">>> ")

    # TODO: 设置挂载目录
    cfg = {
        "image": image,
        "partition": partition,
        "data_sources": data_sources,
        "config": config_path or config,
        "tmpdir": tmpdir or default_tmpdir,
    }
    if custom_partition is not None:
        cfg["custom_partition"] = custom_partition
    return cfg


def _setup_volc():
    config = os.environ.get("CLUSTERX_VOLC_CONFIG", str(Path().home() / ".volc/config.yaml"))
    print(f"请输入火山云配置文件，默认使用 {config}")
    config_path = prompt(">>> ")

    default_tmpdir = os.environ.get("CLUSTERX_VOLC_TMPDIR", str(Path().home() / ".tmp"))
    print(f"请输入任务节点可访问公共目录，回车默认使用 {default_tmpdir}")
    tmpdir = prompt(">>> ")

    # TODO: 设置挂载目录
    return {"config": config_path or config, "tmpdir": tmpdir or default_tmpdir}


def _setup_brainpp():
    print("请输入默认挂载路径，例如（gpfs+gpfs://gpfs1/chenhaodong:/mnt/chenhaodong，如果有多个挂载路径，请以逗号为分隔符输入）")
    mount = prompt(">>>")
    mount = mount.split(",")
    print("请输入默认镜像地址")
    image = prompt(">>>")
    print("请输入默认资源组")
    group = prompt(">>>")
    default_tmpdir = os.environ.get("CLUSTERX_BRAINPP_TMPDIR", str(Path().home() / ".tmp"))
    print(f"请输入任务节点可访问公共目录，回车默认使用 {default_tmpdir}")
    tmpdir = prompt(">>> ")
    if tmpdir == "":
        tmpdir = default_tmpdir
    print("请输入项目组名称")
    project_name = prompt(">>>")
    if not _is_in_yidian_workspace():
        print("检测到当前环境不在仪电开发机，请输入access_key")
        access_key = prompt(">>>")
    else:
        with open("/.auth/accesskey_id") as key_file_obj:
            access_key = key_file_obj.read()

    if not _is_in_yidian_workspace():
        print("请输入secret_key")
        secret_key = prompt(">>>")
    else:
        with open("/.auth/accesskey_secret") as key_file_obj:
            secret_key = key_file_obj.read()

    cfg = {
        "image": image,
        "mount": mount,
        "partition": group,
        "tmpdir": tmpdir,
        "project_name": project_name,
        "access_key": access_key,
        "secret_key": secret_key,
        "is_in_workspace": _is_in_yidian_workspace(),
    }
    return cfg

def _is_in_yidian_workspace():
    return Path("/.auth/accesskey_id").exists() and Path("/.auth/accesskey_secret").exists()

def configure(
    *,
    reset: Annotated[bool, Parameter(help="是否重新配置 ", negative="")] = False,
    show: Annotated[bool, Parameter(help="查看配置文件路径", negative="")] = False,
):
    if reset:
        if DEFAULT_CFG_PATH.exists():
            print(f"发现配置文件路径: {DEFAULT_CFG_PATH}")
            while True:
                confirm = prompt("是否删除已有配置文件，重新配置？Y/N\n>>>")
                if confirm.lower() == "y":
                    os.remove(DEFAULT_CFG_PATH)
                    _configure()
                    return
                elif confirm.lower() == "n":
                    return
                else:
                    print("请输入 Y/N")
                    continue
        return _configure()

    if show:
        if DEFAULT_CFG_PATH.exists():
            with open(DEFAULT_CFG_PATH, "r") as f:
                print("=" * 100)
                print(f"配置文件路径: {DEFAULT_CFG_PATH}")
                print("=" * 100)
                print(f"配置文件内容: {f.read()}")
        else:
            print(f"配置文件路径: {DEFAULT_CFG_PATH} 不存在")
        return


def _configure():
    if not DEFAULT_CFG_PATH.exists():
        DEFAULT_CFG_PATH.parent.mkdir(parents=True, exist_ok=True)
        default = prompt(f"输入集群名 ({VALID_CUSTER}) >>> ", completer=WordCompleter(VALID_CUSTER))
        assert default in VALID_CUSTER, f"Invalid cluster name: {default}"
        default_cfg = {
            "default": default,
        }

        if default == "aliyun":
            default_cfg["aliyun"] = _set_aliyun_config()
        elif default == "volc":
            default_cfg["volc"] = _setup_volc()
        elif default == "yidian":
            default_cfg["yidian"] = _setup_brainpp()

        clusterx_config = ClusterXConfig(**default_cfg)
        with open(DEFAULT_CFG_PATH, "w") as f:
            yaml.dump(clusterx_config.model_dump(), f, Dumper=yaml.Dumper)
            print(f"配置文件保存至 {DEFAULT_CFG_PATH}")
    else:
        with open(DEFAULT_CFG_PATH, "r") as f:
            try:
                _cfg = yaml.load(f, Loader=yaml.Loader) or {}
                clusterx_config = ClusterXConfig(**_cfg)
            except ValidationError as e:
                raise RuntimeError(f"Invalid config file: {DEFAULT_CFG_PATH} for {e}, please remove it and retry")

    return clusterx_config


if not DEFAULT_CFG_PATH.exists():
    CLUSTERX_CONFIG = _configure()
else:
    with open(DEFAULT_CFG_PATH, "r") as f:
        try:
            _cfg = yaml.load(f, Loader=yaml.Loader) or {}
        except ValidationError as e:
            raise RuntimeError(f"Invalid config file: {DEFAULT_CFG_PATH} for {e}, please remove it and retry")
        else:
            CLUSTERX_CONFIG = ClusterXConfig(**_cfg)


# TODO: Default parameter for each cluster
CLUSTER = CLUSTERX_CONFIG.default
